#include <stdio.h>
#include "xparameters.h"
#include "xiic.h"
#include "xiic_l.h"
#include "xil_io.h"
#include "xaxivdma.h"
#include "xtft.h"

#define FRAME_BUFFER_ADDR 0x80000000

// comment this to switch to QVGA output
#define VGA

////////////////////////////////////////////////////////////////////////////////
// sendcmd:
//
// cmd: (32-bit) integer
//
// This function sends the bottom 24 bits of 'cmd' through the IIC port to the
// address of the OV5640 camera. Bytes are sent from upper to lower i.e.
// cmd[23:16]
// cmd[15:8]
// cmd[7:0]
//
// Note the OV5640 uses its own interface called SCCB, but is generally
// compatible with I2C. The address 0x3C is translated from the SCCB address
// of 0x78
////////////////////////////////////////////////////////////////////////////////
void sendcmd(int cmd)
{
  u8 cmdb[3];                   // buffer for bytes to send
  volatile unsigned SendCount;  // return code from XIic_Send

  // Load the byte buffer
  cmdb[0] = (cmd >> 16) & 0xFF;
  cmdb[1] = (cmd >> 8) & 0xFF;
  cmdb[2] = cmd & 0xFF;

  do {
    // Try Send
    SendCount = XIic_Send(XPAR_AXI_IIC_0_BASEADDR,
                          0x3c,                     // I2C Address of OV5640
                          cmdb, 3,
                          XIIC_STOP);

    // Clear the TX FIFO on failure
    if (SendCount != 3) {
      XIic_WriteReg(XPAR_AXI_IIC_0_BASEADDR,  XIIC_CR_REG_OFFSET,
                    XIIC_CR_TX_FIFO_RESET_MASK);
      XIic_WriteReg(XPAR_AXI_IIC_0_BASEADDR, XIIC_CR_REG_OFFSET,
                    XIIC_CR_ENABLE_DEVICE_MASK);
    }
  } while (SendCount != 3);
}

int main ()
{
  XAxiVdma AxiVdma;
  XAxiVdma_Config *Config;
  XAxiVdma_FrameCounter FrameCfg;
  int Status;
  XTft TftInstance;
  XAxiVdma_DmaSetup WriteCfg;

  ////////////////////////////////////////////////////////////
  // Set up the OV5640 Camera Registers
  ////////////////////////////////////////////////////////////

  //from the reference manual
  sendcmd(0x310311); // SCCB SYSTEM CTRL1
  sendcmd(0x300882);
  sendcmd(0x300842);
  sendcmd(0x310303);
  sendcmd(0x3017ff);
  sendcmd(0x3018ff);
  sendcmd(0x30341a);
  sendcmd(0x363036);
  sendcmd(0x36310e);
  sendcmd(0x3632e2);
  sendcmd(0x363312);
  sendcmd(0x3621e0);
  sendcmd(0x3704a0);
  sendcmd(0x37035a);
  sendcmd(0x371578);
  sendcmd(0x371701);
  sendcmd(0x370b60);
  sendcmd(0x37051a);
  sendcmd(0x390502);
  sendcmd(0x390610);
  sendcmd(0x39010a);
  sendcmd(0x373112);
  sendcmd(0x360008);
  sendcmd(0x360133);
  sendcmd(0x302d60);
  sendcmd(0x362052);
  sendcmd(0x371b20);
  sendcmd(0x471c50);
  sendcmd(0x3a1343);
  sendcmd(0x3a1800);
  sendcmd(0x3a19f8);
  sendcmd(0x363513);
  sendcmd(0x363603);
  sendcmd(0x363440);
  sendcmd(0x362201);
  sendcmd(0x3c0134);
  sendcmd(0x3c0428);
  sendcmd(0x3c0598);
  sendcmd(0x3c0600);
  sendcmd(0x3c0708);
  sendcmd(0x3c0800);
  sendcmd(0x3c091c);
  sendcmd(0x3c0a9c);
  sendcmd(0x3c0b40);
  sendcmd(0x382007);
  sendcmd(0x382100);
  sendcmd(0x381431);
  sendcmd(0x381531);
  //image windowing registers, control scaling size
  sendcmd(0x380000); // start at X = 0
  sendcmd(0x380100);
  sendcmd(0x380200); // start at Y = 4
  sendcmd(0x380300);
  sendcmd(0x38040a); // end at X = 0xa3f
  sendcmd(0x38051f);
  sendcmd(0x380607); // end at Y = 0x79b
  sendcmd(0x380787);

//TIMING DVPHO (Data Valid Pixel Horizontal Output Size)
#ifdef VGA
//These two lines are setting the TIMING HSIZE, which controls the horizontal width of the image.
//The value 0x02 (high byte) and 0x80 (low byte) combined (0x0280) set the width to 640 pixels for a VGA resolution.
  sendcmd(0x380802); // 640
  sendcmd(0x380980);
//These two lines are setting the TIMING VSIZE, which controls the vertical height of the image.
//The value 0x01 (high byte) and 0xe0 (low byte) combined (0x01E0) set the height to 480 pixels for a VGA resolution.
  sendcmd(0x380a01); // 480
  sendcmd(0x380be0);
//dummy data pad speed, 0x20 is default value
  sendcmd(0x460c20);
#else
  sendcmd(0x380801); // 320
  sendcmd(0x380940);
  sendcmd(0x380a00); // 240
  sendcmd(0x380bf0);
  sendcmd(0x460c22); // QVGA
#endif
  //TIMING HTS Total horizontal size[11:8] high byte
  sendcmd(0x380c07);
  // Total horizontal size[7:0] low byte
  sendcmd(0x380d68);
  //Total vertical size[15:8] high byte
  sendcmd(0x380e05);
  //Total vertical size[7:0] low byte
  sendcmd(0x380fb0);

  //PLL (Phase Locked Loop) multiplier of the camera sensor.
  sendcmd(0x303514);
  //sensor's clock configuration
  sendcmd(0x303638);
  //configuring additional PLL settings, such as post-dividers
  //or enabling/disabling certain PLL components
  sendcmd(0x303713);
  // SYSTEM ROOT DIVIDER, 01: PCLK = pll_clki/2
  sendcmd(0x310801);

  sendcmd(0x382402);
  //TIMING HOFFSET
  sendcmd(0x381000);
  //TIMING HOFFSET
  sendcmd(0x381108);
  //TIMING VOFFSET
  sendcmd(0x381200);
  //TIMING VOFFSET
  sendcmd(0x381302);

  sendcmd(0x361800);
  sendcmd(0x361229);
  sendcmd(0x370864);
  sendcmd(0x370952);
  sendcmd(0x370c03);

  //Night mode
//  sendcmd(0x3a0078);
  sendcmd(0x3a0203);
  sendcmd(0x3a03d8);
  sendcmd(0x3a0801);
  sendcmd(0x3a0927);
  sendcmd(0x3a0a00);
  sendcmd(0x3a0bf6);
  sendcmd(0x3a0e03);
  sendcmd(0x3a0d04);
  sendcmd(0x3a1403);
  sendcmd(0x3a15d8);

  //debug mode
  sendcmd(0x400102);
  sendcmd(0x400402);

  sendcmd(0x560122);
  //DVP control
  sendcmd(0x474500);

  //System Reset & Clock Enable
  sendcmd(0x300000);
  sendcmd(0x30021c);
  sendcmd(0x3004ff);
  sendcmd(0x3006c3);

  sendcmd(0x300e58);//PWDN
  sendcmd(0x302e00);

  sendcmd(0x430023); // Format setting to RGB888 //0X4300 is a control register,0X09 0x0A are two correct 444 forms. 0x430009 or 0x43000A
  sendcmd(0x471306); //DVP Control
  sendcmd(0x440704); //JPEG Control
  sendcmd(0x440e00);
  sendcmd(0x460b35); //VFIFO Control
  sendcmd(0x5000a7); //ISP top control
  sendcmd(0x5001a5);
  sendcmd(0x500308);
  sendcmd(0x5180ff);
  sendcmd(0x5181f2); //AWB Control
  sendcmd(0x518200);
  sendcmd(0x518314);
  sendcmd(0x518425);
  sendcmd(0x518524);
  sendcmd(0x518609);
  sendcmd(0x518709);
  sendcmd(0x518809);
  sendcmd(0x518975);
  sendcmd(0x518a54);
  sendcmd(0x518be0);
  sendcmd(0x518cb2);
  sendcmd(0x518d42);
  sendcmd(0x518e3d);
  sendcmd(0x518f56);
  sendcmd(0x519046);
  sendcmd(0x5191f8);
  sendcmd(0x519204);
  sendcmd(0x519370);
  sendcmd(0x5194f0);
  sendcmd(0x5195f0);
  sendcmd(0x519603);
  sendcmd(0x519701);
  sendcmd(0x519804);
  sendcmd(0x519912);
  sendcmd(0x519a04);
  sendcmd(0x519b00);
  sendcmd(0x519c06);
  sendcmd(0x519d82);
  sendcmd(0x519e38);

  sendcmd(0x53811e);//CMX Control
  sendcmd(0x53825b);
  sendcmd(0x538308);
  sendcmd(0x53840a);
  sendcmd(0x53857e);
  sendcmd(0x538688);
  sendcmd(0x53877c);
  sendcmd(0x53886c);
  sendcmd(0x538910);
  sendcmd(0x538a01);
  sendcmd(0x538b98);
  sendcmd(0x530008);
  //sendcmd(0x530130); // CIP regs
  //sendcmd(0x530210);
  //sendcmd(0x530300);
  //sendcmd(0x530408);
  //sendcmd(0x530530);
  //sendcmd(0x530608);
  //sendcmd(0x530716);
  //sendcmd(0x530908);
  //sendcmd(0x530a30);
  //sendcmd(0x530b04);
  //sendcmd(0x530c06); // CIP regs done
  sendcmd(0x548001);//gamma control p37
  sendcmd(0x548108);
  sendcmd(0x548214);
  sendcmd(0x548328);
  sendcmd(0x548451);
  sendcmd(0x548565);
  sendcmd(0x548671);
  sendcmd(0x54877d);
  sendcmd(0x548887);
  sendcmd(0x548991);
  sendcmd(0x548a9a);
  sendcmd(0x548baa);
  sendcmd(0x548cb8);
  sendcmd(0x548dcd);
  sendcmd(0x548edd);
  sendcmd(0x548fea);
  sendcmd(0x54901d);

  sendcmd(0x558007); // SDE Control saturation
  sendcmd(0x558340);
  sendcmd(0x558440);
  sendcmd(0x558625);
//  sendcmd(0x558630);
  sendcmd(0x558841);
  sendcmd(0x558910);
  sendcmd(0x558a00);
  sendcmd(0x558bf8);
  //LENC control
  sendcmd(0x580023);
  sendcmd(0x580114);
  sendcmd(0x58020f);
  sendcmd(0x58030f);
  sendcmd(0x580412);
  sendcmd(0x580526);
  sendcmd(0x58060c);
  sendcmd(0x580708);
  sendcmd(0x580805);
  sendcmd(0x580905);
  sendcmd(0x580a08);
  sendcmd(0x580b0d);
  sendcmd(0x580c08);
  sendcmd(0x580d03);
  sendcmd(0x580e00);
  sendcmd(0x580f00);
  sendcmd(0x581003);
  sendcmd(0x581109);
  sendcmd(0x581207);
  sendcmd(0x581303);
  sendcmd(0x581400);
  sendcmd(0x581501);
  sendcmd(0x581603);
  sendcmd(0x581708);
  sendcmd(0x58180d);
  sendcmd(0x581908);
  sendcmd(0x581a05);
  sendcmd(0x581b06);
  sendcmd(0x581c08);
  sendcmd(0x581d0e);
  sendcmd(0x581e29);
  sendcmd(0x581f17);
  sendcmd(0x582011);
  sendcmd(0x582111);
  sendcmd(0x582215);
  sendcmd(0x582328);
  sendcmd(0x582446);
  sendcmd(0x582526);
  sendcmd(0x582608);
  sendcmd(0x582726);
  sendcmd(0x582864);
  sendcmd(0x582926);
  sendcmd(0x582a24);
  sendcmd(0x582b22);
  sendcmd(0x582c24);
  sendcmd(0x582d24);
  sendcmd(0x582e06);
  sendcmd(0x582f22);
  sendcmd(0x583040);
  sendcmd(0x583142);
  sendcmd(0x583224);
  sendcmd(0x583326);
  sendcmd(0x583424);
  sendcmd(0x583522);
  sendcmd(0x583622);
  sendcmd(0x583726);
  sendcmd(0x583844);
  sendcmd(0x583924);
  sendcmd(0x583a26);
  sendcmd(0x583b28);
  sendcmd(0x583c42);
  sendcmd(0x583dce);

  sendcmd(0x502500);
//  image luminance
  sendcmd(0x3a0f30);
  sendcmd(0x3a1028);
  sendcmd(0x3a1b30);
  sendcmd(0x3a1e26);
  // fast AEC range in manual speed selection made
  sendcmd(0x3a1160);
  sendcmd(0x3a1f14);

  sendcmd(0x300802);
  sendcmd(0x303521);
  //FORMAT MUX CONTROL
  sendcmd(0x501f00);


  //sendcmd(0x30361c);
  sendcmd(0x303630); // Clock Multiplier, configure frame rate

  ////////////////////////////////////////
  // Test Pattern:
  ////////////////////////////////////////
  // Turn on:
  // sendcmd(0x503d80);
  // Turn off
  // sendcmd(0x503d00);

  ////////////////////////////////////////
  // Turn on flash: write 0x3b0700 to turn off
  ////////////////////////////////////////
  //sendcmd(0x301602);
  //sendcmd(0x3b0083);
  //sendcmd(0x3b0703);

  ////////////////////////////////////////////////////////////
  // TFT Config
  ////////////////////////////////////////////////////////////

  TftInstance.TftConfig.DeviceId = XPAR_AXI_TFT_0_DEVICE_ID;
  TftInstance.TftConfig.BaseAddress = XPAR_AXI_TFT_0_BASEADDR;
  TftInstance.TftConfig.VideoMemBaseAddr = FRAME_BUFFER_ADDR;
  TftInstance.IsReady = XIL_COMPONENT_IS_READY;

  // Set the base address to read from
  XTft_SetFrameBaseAddr(&TftInstance, FRAME_BUFFER_ADDR);

  ////////////////////////////////////////////////////////////
  // Configure VDMA
  ////////////////////////////////////////////////////////////

  // Get Hardware VDMA Config from device ID
  Config = XAxiVdma_LookupConfig(XPAR_AXI_VDMA_0_DEVICE_ID);
  // Initialize the VDMA
  Status = XAxiVdma_CfgInitialize(&AxiVdma, Config, Config->BaseAddress);

  // Define a DMA Transfer Configuration
  // The size and stride matches the AXI TFT requirements
  WriteCfg.VertSizeInput = 480;
  WriteCfg.HoriSizeInput = 640*4; // 640 pixels by 4 bytes per pixel
  WriteCfg.Stride = 1024*4;
  WriteCfg.FrameDelay = 0;
  WriteCfg.PointNum = 0;
  WriteCfg.EnableFrameCounter = 0;
  WriteCfg.EnableCircularBuf = 0;
  WriteCfg.EnableSync = 1;
  WriteCfg.FixedFrameStoreAddr = 0;
  WriteCfg.FrameStoreStartAddr[0] = FRAME_BUFFER_ADDR;

  // Apply the write transfer config
  Status = XAxiVdma_DmaConfig(&AxiVdma, XAXIVDMA_WRITE, &WriteCfg);
  // Set the destination address to be the base address of DDR memory
  // same location as the AXI TFT
  Status = XAxiVdma_DmaSetBufferAddr(&AxiVdma, XAXIVDMA_WRITE, WriteCfg.FrameStoreStartAddr);
  Status = XAxiVdma_DmaStart(&AxiVdma, XAXIVDMA_WRITE);
  Status = XAxiVdma_StartParking(&AxiVdma, 0, XAXIVDMA_WRITE);
  return 0;

}
